<?php
/**
 * Created by ra on 6/13/2015.
 */



td_demo_media::add_image_to_media_gallery('td_pic_logo_footer',         'http://demo_content.tagdiv.com/Newspaper_6/tech/tech-footer.png');

//ads
td_demo_media::add_image_to_media_gallery('td_tech_ad_full',            "http://demo_content.tagdiv.com/Newspaper_6/tech/rec728.jpg");
td_demo_media::add_image_to_media_gallery('td_tech_ad_sidebar',         "http://demo_content.tagdiv.com/Newspaper_6/tech/rec300.jpg");

